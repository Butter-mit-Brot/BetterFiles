With this Python package you should be able to create and maintain Files much easier and better.

For more detailed information or how to use the package go on the github repository(https://github.com/Butter-mit-Brot/BetterFiles)